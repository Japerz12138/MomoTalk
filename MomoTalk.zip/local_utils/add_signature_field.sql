-- Add signature field to users table
ALTER TABLE users ADD COLUMN signature VARCHAR(100) DEFAULT '' AFTER nickname;



