-- Step 1: Add momo_code column to users table (if not exists)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS momo_code VARCHAR(14) NULL UNIQUE;

-- Step 2: After running generate_momo_codes.js, you can make it NOT NULL
-- ALTER TABLE users 
-- MODIFY COLUMN momo_code VARCHAR(14) NOT NULL UNIQUE;

-- Note: Run generate_momo_codes.js script to generate Momo Codes for existing users
-- Command: node generate_momo_codes.js

