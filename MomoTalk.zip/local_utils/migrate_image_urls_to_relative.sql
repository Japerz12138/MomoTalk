-- Migration script to convert absolute image URLs to relative paths
-- This updates all image URLs in the database from http://localhost:5000/... to /...
-- Run this after deploying the new code that uses relative paths

-- Update avatar URLs in users table
UPDATE users 
SET avatar = REPLACE(avatar, 'http://localhost:5000/', '/')
WHERE avatar LIKE 'http://localhost:5000/%';

-- Also handle https if any
UPDATE users 
SET avatar = REPLACE(avatar, 'https://localhost:5000/', '/')
WHERE avatar LIKE 'https://localhost:5000/%';

-- Update chat image URLs in dms table
UPDATE dms 
SET image_url = REPLACE(image_url, 'http://localhost:5000/', '/')
WHERE image_url LIKE 'http://localhost:5000/%';

UPDATE dms 
SET image_url = REPLACE(image_url, 'https://localhost:5000/', '/')
WHERE image_url LIKE 'https://localhost:5000/%';

-- Update uploaded_images table (the MD5 cache table)
UPDATE uploaded_images 
SET file_url = REPLACE(file_url, 'http://localhost:5000/', '/')
WHERE file_url LIKE 'http://localhost:5000/%';

UPDATE uploaded_images 
SET file_url = REPLACE(file_url, 'https://localhost:5000/', '/')
WHERE file_url LIKE 'https://localhost:5000/%';

-- Update favorite emojis table
UPDATE favorite_emojis 
SET image_url = REPLACE(image_url, 'http://localhost:5000/', '/')
WHERE image_url LIKE 'http://localhost:5000/%';

UPDATE favorite_emojis 
SET image_url = REPLACE(image_url, 'https://localhost:5000/', '/')
WHERE image_url LIKE 'https://localhost:5000/%';

-- Verify the changes
SELECT 'Users table - Updated avatar URLs:' as Info;
SELECT id, username, avatar FROM users WHERE avatar IS NOT NULL LIMIT 5;

SELECT 'DMs table - Updated image URLs:' as Info;
SELECT id, sender_id, receiver_id, image_url FROM dms WHERE image_url IS NOT NULL LIMIT 5;

SELECT 'Uploaded images cache - Updated URLs:' as Info;
SELECT id, md5_hash, file_url, file_type FROM uploaded_images LIMIT 5;



