-- Add uploaded_images table for MD5-based image deduplication
-- This prevents duplicate image uploads and saves server storage

CREATE TABLE IF NOT EXISTS uploaded_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    md5_hash VARCHAR(32) NOT NULL UNIQUE,
    file_url VARCHAR(500) NOT NULL,
    file_type ENUM('avatar', 'chat') NOT NULL,
    file_size INT NOT NULL,
    upload_count INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_md5_hash (md5_hash),
    INDEX idx_file_type (file_type)
);

-- Note: Run this SQL file to add the table to an existing database
-- Command: mysql -u username -p database_name < add_image_md5_table.sql

