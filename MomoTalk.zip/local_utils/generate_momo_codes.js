require('dotenv').config();
const mysql = require('mysql2');

const DB_CONFIG = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
};

if (!DB_CONFIG.user || !DB_CONFIG.password || !DB_CONFIG.database) {
    console.error('Database configuration is incomplete. Please check your environment variables.');
    process.exit(1);
}

// Momo Code generation function
function generateMomoCode() {
    // Generate 12 random digits
    let code = '';
    for (let i = 0; i < 12; i++) {
        code += Math.floor(Math.random() * 10);
    }
    // Format as xxxx-xxxx-xxxx
    return `${code.substring(0, 4)}-${code.substring(4, 8)}-${code.substring(8, 12)}`;
}

async function generateUniqueMomoCode(connection) {
    let momoCode;
    let isUnique = false;
    
    while (!isUnique) {
        momoCode = generateMomoCode();
        // Check if this code already exists
        const [rows] = await connection.promise().query('SELECT id FROM users WHERE momo_code = ?', [momoCode]);
        if (rows.length === 0) {
            isUnique = true;
        }
    }
    
    return momoCode;
}

async function generateMomoCodesForExistingUsers() {
    const connection = mysql.createConnection(DB_CONFIG);

    try {
        await connection.promise().connect();
        console.log('Connected to the database');

        // First, add the momo_code column if it doesn't exist
        console.log('Adding momo_code column if it doesn\'t exist...');
        try {
            await connection.promise().query(`
                ALTER TABLE users 
                ADD COLUMN momo_code VARCHAR(14) NULL UNIQUE
            `);
            console.log('Column momo_code added successfully');
        } catch (err) {
            if (err.code === 'ER_DUP_FIELDNAME') {
                console.log('Column momo_code already exists');
            } else {
                throw err;
            }
        }

        // Get all users without a momo_code
        const [users] = await connection.promise().query('SELECT id FROM users WHERE momo_code IS NULL');
        
        console.log(`Found ${users.length} users without Momo Codes`);
        
        if (users.length === 0) {
            console.log('All users already have Momo Codes!');
            connection.end();
            return;
        }

        // Generate and assign Momo Codes to each user
        for (const user of users) {
            const momoCode = await generateUniqueMomoCode(connection);
            await connection.promise().query('UPDATE users SET momo_code = ? WHERE id = ?', [momoCode, user.id]);
            console.log(`Generated Momo Code ${momoCode} for user ID ${user.id}`);
        }

        console.log(`Successfully generated Momo Codes for ${users.length} users!`);
        
        // Make the momo_code column NOT NULL after all users have codes
        console.log('Making momo_code column NOT NULL...');
        try {
            await connection.promise().query(`
                ALTER TABLE users 
                MODIFY COLUMN momo_code VARCHAR(14) NOT NULL UNIQUE
            `);
            console.log('Column momo_code is now NOT NULL');
        } catch (err) {
            console.error('Error making momo_code NOT NULL:', err.message);
        }

        connection.end();
        console.log('Done!');
    } catch (error) {
        console.error('Error:', error.message);
        connection.end();
        process.exit(1);
    }
}

generateMomoCodesForExistingUsers();

